import React, { useEffect, useState } from 'react';
import { 
  Github, 
  Linkedin, 
  Mail, 
  Youtube, 
  Twitter, 
  ArrowDown, 
  Menu, 
  X,
  Brain,
  Rocket,
  Lightbulb,
  Code,
  Phone
} from 'lucide-react';
import './App.css';

function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [activeSection, setActiveSection] = useState('home');
  const [isLoaded, setIsLoaded] = useState(false);

  useEffect(() => {
    setIsLoaded(true);
    
    const handleScroll = () => {
      const sections = document.querySelectorAll('section');
      let current = '';
      
      sections.forEach(section => {
        const sectionTop = section.offsetTop;
        const sectionHeight = section.clientHeight;
        if (window.scrollY >= sectionTop - 200) {
          current = section.getAttribute('id') || '';
        }
      });
      
      if (current && current !== activeSection) {
        setActiveSection(current);
      }
    };
    
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, [activeSection]);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  const scrollToSection = (sectionId: string) => {
    setIsMenuOpen(false);
    const section = document.getElementById(sectionId);
    if (section) {
      window.scrollTo({
        top: section.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      {/* Header */}
      <header className="fixed w-full bg-gray-900/90 backdrop-blur-sm z-50 border-b border-blue-500/20">
        <div className="container mx-auto px-6 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">
            MFK
          </div>
          
          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            {['home', 'about', 'wincept', 'ai-academy', 'youtube', 'contact'].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item)}
                className={`text-sm uppercase tracking-wider hover:text-blue-400 transition-colors ${
                  activeSection === item ? 'text-blue-400 font-medium' : 'text-gray-300'
                }`}
              >
                {item === 'home' ? 'Home' : 
                 item === 'about' ? 'About Me' : 
                 item === 'wincept' ? 'Wincept' : 
                 item === 'ai-academy' ? 'AI Academy' : 
                 item === 'youtube' ? 'YouTube & Socials' : 'Contact'}
              </button>
            ))}
          </nav>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden text-gray-300 focus:outline-none"
            onClick={toggleMenu}
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
        
        {/* Mobile Navigation */}
        <div 
          className={`md:hidden absolute w-full bg-gray-800 transition-all duration-300 ease-in-out ${
            isMenuOpen ? 'max-h-screen opacity-100' : 'max-h-0 opacity-0 overflow-hidden'
          }`}
        >
          <div className="container mx-auto px-6 py-4 flex flex-col space-y-4">
            {['home', 'about', 'wincept', 'ai-academy', 'youtube', 'contact'].map((item) => (
              <button
                key={item}
                onClick={() => scrollToSection(item)}
                className={`text-sm uppercase tracking-wider py-2 hover:text-blue-400 transition-colors ${
                  activeSection === item ? 'text-blue-400 font-medium' : 'text-gray-300'
                }`}
              >
                {item === 'home' ? 'Home' : 
                 item === 'about' ? 'About Me' : 
                 item === 'wincept' ? 'Wincept' : 
                 item === 'ai-academy' ? 'AI Academy' : 
                 item === 'youtube' ? 'YouTube & Socials' : 'Contact'}
              </button>
            ))}
          </div>
        </div>
      </header>

      <main>
        {/* Hero Section */}
        <section 
          id="home" 
          className={`min-h-screen flex items-center justify-center relative overflow-hidden transition-opacity duration-1000 ${isLoaded ? 'opacity-100' : 'opacity-0'}`}
        >
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1451187580459-43490279c0fa?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80')] bg-cover bg-center opacity-10"></div>
          <div className="absolute inset-0 bg-gradient-to-b from-gray-900/50 to-gray-900"></div>
          
          <div className="container mx-auto px-6 z-10 text-center">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 animate-fadeIn">
              <span className="block">Muhammed Fasil K</span>
              <span className="block mt-2 text-xl md:text-2xl lg:text-3xl font-normal text-gray-300">Founder & CTO, Wincept Technologies</span>
            </h1>
            <p className="text-xl md:text-2xl lg:text-3xl mb-8 max-w-3xl mx-auto text-blue-300 animate-fadeInDelay">
              Innovating the Future with AI & Design
            </p>
            <div className="flex justify-center space-x-4 animate-fadeInDelay2">
              <a href="#about" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-3 rounded-full transition-all duration-300 flex items-center space-x-2 transform hover:scale-105">
                <span>Discover My Journey</span>
                <ArrowDown size={16} />
              </a>
              <a href="#contact" className="bg-transparent border border-blue-500 text-blue-400 hover:bg-blue-900/30 px-8 py-3 rounded-full transition-all duration-300 transform hover:scale-105">
                Get In Touch
              </a>
            </div>
          </div>
          
          <div className="absolute bottom-10 left-0 right-0 flex justify-center animate-bounce">
            <ArrowDown size={24} className="text-blue-400" />
          </div>
        </section>

        {/* About Me Section */}
        <section id="about" className="py-20 bg-gray-800">
          <div className="container mx-auto px-6">
            <div className="flex flex-col md:flex-row items-center gap-12">
              <div className="md:w-1/2">
                <div className="relative">
                  <div className="w-64 h-64 md:w-80 md:h-80 rounded-full overflow-hidden border-4 border-blue-500 mx-auto">
                    <img 
                      src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                      alt="Muhammed Fasil K" 
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute -bottom-4 -right-4 bg-blue-600 rounded-full p-4">
                    <Brain size={32} className="text-white" />
                  </div>
                </div>
              </div>
              
              <div className="md:w-1/2">
                <h2 className="text-3xl md:text-4xl font-bold mb-6 relative">
                  <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">About Me</span>
                  <div className="h-1 w-20 bg-blue-500 mt-2"></div>
                </h2>
                
                <p className="text-gray-300 mb-6">
                  As the Founder and CTO of Wincept Technologies, I lead a team of passionate innovators dedicated to creating impactful digital solutions. With over a decade of experience in technology and design, I've developed a unique perspective on how AI can transform businesses and education.
                </p>
                
                <p className="text-gray-300 mb-6">
                  My journey began with a fascination for how technology can solve complex problems. Today, I channel that passion into building cutting-edge products that merge artificial intelligence with intuitive design, creating experiences that are both powerful and accessible.
                </p>
                
                <div className="grid grid-cols-2 gap-4 mb-8">
                  <div className="bg-gray-700/50 p-4 rounded-lg border border-blue-500/20">
                    <h3 className="font-semibold text-blue-400 mb-2">AI & Machine Learning</h3>
                    <p className="text-sm text-gray-300">Developing intelligent systems that learn and adapt</p>
                  </div>
                  <div className="bg-gray-700/50 p-4 rounded-lg border border-blue-500/20">
                    <h3 className="font-semibold text-blue-400 mb-2">UX/UI Design</h3>
                    <p className="text-sm text-gray-300">Creating intuitive interfaces that delight users</p>
                  </div>
                  <div className="bg-gray-700/50 p-4 rounded-lg border border-blue-500/20">
                    <h3 className="font-semibold text-blue-400 mb-2">Tech Leadership</h3>
                    <p className="text-sm text-gray-300">Guiding teams to build innovative solutions</p>
                  </div>
                  <div className="bg-gray-700/50 p-4 rounded-lg border border-blue-500/20">
                    <h3 className="font-semibold text-blue-400 mb-2">Entrepreneurship</h3>
                    <p className="text-sm text-gray-300">Building ventures that create lasting impact</p>
                  </div>
                </div>
                
                <div className="flex space-x-4">
                  <a href="#wincept" className="text-blue-400 hover:text-blue-300 transition-colors">
                    Learn about my company →
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Wincept Section */}
        <section id="wincept" className="py-20 bg-gray-900 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-1/2 h-full bg-blue-900/10 rounded-l-full blur-3xl"></div>
          <div className="container mx-auto px-6 relative z-10">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">Wincept Technologies</span>
              </h2>
              <p className="text-gray-300 max-w-3xl mx-auto">
                Founded with a vision to create technology that makes a difference, Wincept Technologies specializes in AI-powered solutions, custom software development, and digital transformation.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="bg-gray-800/80 backdrop-blur-sm p-6 rounded-xl border border-blue-500/20 transform transition-all duration-300 hover:scale-105 hover:border-blue-500/50">
                <div className="bg-blue-600/20 p-3 rounded-full w-fit mb-4">
                  <Rocket size={28} className="text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-white">AI Solutions</h3>
                <p className="text-gray-300">
                  We develop custom AI solutions that help businesses automate processes, gain insights from data, and create intelligent user experiences.
                </p>
              </div>
              
              <div className="bg-gray-800/80 backdrop-blur-sm p-6 rounded-xl border border-blue-500/20 transform transition-all duration-300 hover:scale-105 hover:border-blue-500/50">
                <div className="bg-blue-600/20 p-3 rounded-full w-fit mb-4">
                  <Code size={28} className="text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-white">Software Development</h3>
                <p className="text-gray-300">
                  Our team builds robust, scalable software solutions tailored to your specific business needs, from web applications to mobile apps.
                </p>
              </div>
              
              <div className="bg-gray-800/80 backdrop-blur-sm p-6 rounded-xl border border-blue-500/20 transform transition-all duration-300 hover:scale-105 hover:border-blue-500/50">
                <div className="bg-blue-600/20 p-3 rounded-full w-fit mb-4">
                  <Lightbulb size={28} className="text-blue-400" />
                </div>
                <h3 className="text-xl font-semibold mb-3 text-white">Digital Transformation</h3>
                <p className="text-gray-300">
                  We guide businesses through digital transformation, helping them leverage technology to improve operations and customer experiences.
                </p>
              </div>
            </div>
            
            <div className="mt-16">
              <h3 className="text-2xl font-semibold mb-8 text-center">Featured Projects</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="bg-gray-800/50 rounded-xl overflow-hidden">
                  <div className="h-48 bg-[url('https://images.unsplash.com/photo-1551288049-bebda4e38f71?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80')] bg-cover bg-center"></div>
                  <div className="p-6">
                    <h4 className="text-xl font-semibold mb-2 text-white">AI-Powered Analytics Platform</h4>
                    <p className="text-gray-300 mb-4">
                      A comprehensive analytics solution that uses machine learning to provide predictive insights and actionable recommendations.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <span className="text-xs bg-blue-900/50 text-blue-300 px-3 py-1 rounded-full">Machine Learning</span>
                      <span className="text-xs bg-blue-900/50 text-blue-300 px-3 py-1 rounded-full">Data Visualization</span>
                      <span className="text-xs bg-blue-900/50 text-blue-300 px-3 py-1 rounded-full">Cloud Architecture</span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gray-800/50 rounded-xl overflow-hidden">
                  <div className="h-48 bg-[url('https://images.unsplash.com/photo-1556155092-490a1ba16284?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80')] bg-cover bg-center"></div>
                  <div className="p-6">
                    <h4 className="text-xl font-semibold mb-2 text-white">Smart Retail Solution</h4>
                    <p className="text-gray-300 mb-4">
                      An integrated system that combines IoT sensors, computer vision, and AI to optimize retail operations and enhance customer experiences.
                    </p>
                    <div className="flex flex-wrap gap-2">
                      <span className="text-xs bg-blue-900/50 text-blue-300 px-3 py-1 rounded-full">Computer Vision</span>
                      <span className="text-xs bg-blue-900/50 text-blue-300 px-3 py-1 rounded-full">IoT</span>
                      <span className="text-xs bg-blue-900/50 text-blue-300 px-3 py-1 rounded-full">Real-time Analytics</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* AI Academy Section */}
        <section id="ai-academy" className="py-20 bg-gray-800 relative">
          <div className="absolute inset-0 bg-[url('https://images.unsplash.com/photo-1581092918056-0c4c3acd3789?ixlib=rb-1.2.1&auto=format&fit=crop&w=1920&q=80')] bg-cover bg-center opacity-5"></div>
          <div className="container mx-auto px-6 relative z-10">
            <div className="max-w-3xl mx-auto text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">AI Academy</span>
              </h2>
              <p className="text-gray-300">
                My vision for democratizing AI education and empowering the next generation of innovators through accessible, practical learning experiences.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
              <div>
                <h3 className="text-2xl font-semibold mb-4 text-white">The Vision</h3>
                <p className="text-gray-300 mb-6">
                  AI Academy is born from my belief that artificial intelligence should be accessible to everyone. Our mission is to demystify AI and provide practical, hands-on education that bridges the gap between theory and real-world application.
                </p>
                
                <h3 className="text-2xl font-semibold mb-4 text-white">Our Approach</h3>
                <p className="text-gray-300 mb-6">
                  We focus on project-based learning that gives students the skills to build AI solutions from day one. Our curriculum is designed by industry experts and constantly updated to reflect the latest advancements in the field.
                </p>
                
                <div className="space-y-4">
                  <div className="flex items-start">
                    <div className="bg-blue-600/20 p-2 rounded-full mr-4 mt-1">
                      <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold text-blue-300">Practical Skills First</h4>
                      <p className="text-sm text-gray-300">Learn by building real AI projects that solve actual problems</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-blue-600/20 p-2 rounded-full mr-4 mt-1">
                      <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold text-blue-300">Industry-Relevant Curriculum</h4>
                      <p className="text-sm text-gray-300">Courses designed with input from leading AI companies</p>
                    </div>
                  </div>
                  
                  <div className="flex items-start">
                    <div className="bg-blue-600/20 p-2 rounded-full mr-4 mt-1">
                      <div className="w-2 h-2 bg-blue-400 rounded-full"></div>
                    </div>
                    <div>
                      <h4 className="font-semibold text-blue-300">Community-Driven Learning</h4>
                      <p className="text-sm text-gray-300">Collaborate with peers and mentors in a supportive environment</p>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-900 rounded-xl p-8 border border-blue-500/20">
                <h3 className="text-xl font-semibold mb-6 text-center text-white">Featured Courses</h3>
                
                <div className="space-y-6">
                  <div className="bg-gray-800/50 p-4 rounded-lg border border-blue-500/10 hover:border-blue-500/30 transition-all duration-300">
                    <h4 className="font-semibold text-blue-300 mb-2">AI Fundamentals for Everyone</h4>
                    <p className="text-sm text-gray-300 mb-3">
                      A beginner-friendly introduction to AI concepts, tools, and applications with no coding experience required.
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs bg-blue-900/50 text-blue-300 px-3 py-1 rounded-full">8 Weeks</span>
                      <span className="text-xs text-gray-400">Coming Soon</span>
                    </div>
                  </div>
                  
                  <div className="bg-gray-800/50 p-4 rounded-lg border border-blue-500/10 hover:border-blue-500/30 transition-all duration-300">
                    <h4 className="font-semibold text-blue-300 mb-2">Machine Learning Engineering</h4>
                    <p className="text-sm text-gray-300 mb-3">
                      Learn to build, deploy, and maintain machine learning systems in production environments.
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs bg-blue-900/50 text-blue-300 px-3 py-1 rounded-full">12 Weeks</span>
                      <span className="text-xs text-gray-400">Coming Soon</span>
                    </div>
                  </div>
                  
                  <div className="bg-gray-800/50 p-4 rounded-lg border border-blue-500/10 hover:border-blue-500/30 transition-all duration-300">
                    <h4 className="font-semibold text-blue-300 mb-2">AI for Business Leaders</h4>
                    <p className="text-sm text-gray-300 mb-3">
                      Strategic frameworks for implementing AI in your organization and driving digital transformation.
                    </p>
                    <div className="flex justify-between items-center">
                      <span className="text-xs bg-blue-900/50 text-blue-300 px-3 py-1 rounded-full">6 Weeks</span>
                      <span className="text-xs text-gray-400">Coming Soon</span>
                    </div>
                  </div>
                </div>
                
                <div className="mt-8 text-center">
                  <button className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-full transition-all duration-300 transform hover:scale-105">
                    Join the Waitlist
                  </button>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* YouTube & Socials Section */}
        <section id="youtube" className="py-20 bg-gray-900">
          <div className="container mx-auto px-6">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold mb-6">
                <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">YouTube & Social Media</span>
              </h2>
              <p className="text-gray-300 max-w-3xl mx-auto">
                Follow my journey as a tech entrepreneur and gain insights into AI, design, and building successful tech ventures.
              </p>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
              <div className="bg-gray-800 rounded-xl overflow-hidden shadow-lg transform transition-all duration-300 hover:scale-105">
                <div className="h-48 bg-[url('https://images.unsplash.com/photo-1611162617213-7d7a39e9b1d7?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80')] bg-cover bg-center relative">
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <Youtube size={48} className="text-red-500" />
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-2 text-white">Building AI Products That Scale</h3>
                  <p className="text-gray-300 text-sm mb-4">
                    A deep dive into the architecture and design principles behind successful AI products.
                  </p>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-400">15K views</span>
                    <a href="#" className="text-blue-400 hover:text-blue-300 text-sm">Watch Now</a>
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-800 rounded-xl overflow-hidden shadow-lg transform transition-all duration-300 hover:scale-105">
                <div className="h-48 bg-[url('https://images.unsplash.com/photo-1498050108023-c5249f4df085?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80')] bg-cover bg-center relative">
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <Youtube size={48} className="text-red-500" />
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-2 text-white">From Idea to Startup: My Journey</h3>
                  <p className="text-gray-300 text-sm mb-4">
                    The story of how Wincept Technologies was born and the lessons learned along the way.
                  </p>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-400">8.5K views</span>
                    <a href="#" className="text-blue-400 hover:text-blue-300 text-sm">Watch Now</a>
                  </div>
                </div>
              </div>
              
              <div className="bg-gray-800 rounded-xl overflow-hidden shadow-lg transform transition-all duration-300 hover:scale-105">
                <div className="h-48 bg-[url('https://images.unsplash.com/photo-1531482615713-2afd69097998?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80')] bg-cover bg-center relative">
                  <div className="absolute inset-0 bg-black/50 flex items-center justify-center">
                    <Youtube size={48} className="text-red-500" />
                  </div>
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-semibold mb-2 text-white">The Future of AI in Education</h3>
                  <p className="text-gray-300 text-sm mb-4">
                    Exploring how artificial intelligence is transforming learning experiences and educational outcomes.
                  </p>
                  <div className="flex justify-between items-center">
                    <span className="text-xs text-gray-400">12K views</span>
                    <a href="#" className="text-blue-400 hover:text-blue-300 text-sm">Watch Now</a>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="text-center mb-12">
              <a href="#" className="bg-red-600 hover:bg-red-700 text-white px-8 py-3 rounded-full transition-all duration-300 inline-flex items-center space-x-2 transform hover:scale-105">
                <Youtube size={20} />
                <span>Subscribe to My Channel</span>
              </a>
            </div>
            
            <div className="bg-gray-800/50 rounded-xl p-8 border border-blue-500/20">
              <h3 className="text-xl font-semibold mb-6 text-center text-white">Connect With Me</h3>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                <a href="#" className="flex flex-col items-center p-4 bg-gray-700/50 rounded-lg hover:bg-gray-700 transition-colors">
                  <Linkedin size={32} className="text-blue-400 mb-2" />
                  <span className="text-sm text-gray-300">LinkedIn</span>
                </a>
                
                <a href="#" className="flex flex-col items-center p-4 bg-gray-700/50 rounded-lg hover:bg-gray-700 transition-colors">
                  <Twitter size={32} className="text-blue-400 mb-2" />
                  <span className="text-sm text-gray-300">Twitter</span>
                </a>
                
                <a href="#" className="flex flex-col items-center p-4 bg-gray-700/50 rounded-lg hover:bg-gray-700 transition-colors">
                  <Github size={32} className="text-blue-400 mb-2" />
                  <span className="text-sm text-gray-300">GitHub</span>
                </a>
                
                <a href="#" className="flex flex-col items-center p-4 bg-gray-700/50 rounded-lg hover:bg-gray-700 transition-colors">
                  <Youtube size={32} className="text-blue-400 mb-2" />
                  <span className="text-sm text-gray-300">YouTube</span>
                </a>
              </div>
            </div>
          </div>
        </section>

        {/* Contact Section */}
        <section id="contact" className="py-20 bg-gray-800 relative">
          <div className="absolute top-0 left-0 w-full h-20 bg-gradient-to-b from-gray-900 to-transparent"></div>
          <div className="container mx-auto px-6">
            <div className="max-w-4xl mx-auto">
              <div className="text-center mb-16">
                <h2 className="text-3xl md:text-4xl font-bold mb-6">
                  <span className="bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent">Get In Touch</span>
                </h2>
                <p className="text-gray-300">
                  Have a project in mind or want to collaborate? I'd love to hear from you.
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                <div className="bg-gray-900 rounded-xl p-8 border border-blue-500/20">
                  <form className="space-y-6">
                    <div>
                      <label htmlFor="name" className="block text-sm font-medium text-gray-300 mb-1">Name</label>
                      <input 
                        type="text" 
                        id="name" 
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Your name"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="block text-sm font-medium text-gray-300 mb-1">Email</label>
                      <input 
                        type="email" 
                        id="email" 
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="your.email@example.com"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="message" className="block text-sm font-medium text-gray-300 mb-1">Message</label>
                      <textarea 
                        id="message" 
                        rows={4}
                        className="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="How can I help you?"
                      ></textarea>
                    </div>
                    
                    <button 
                      type="submit"
                      className="w-full bg-blue-600 hover:bg-blue-700 text-white font-medium py-2 px-4 rounded-lg transition-colors"
                    >
                      Send Message
                    </button>
                  </form>
                </div>
                
                <div>
                  <div className="space-y-8">
                    <div>
                      <h3 className="text-xl font-semibold mb-4 text-white">Contact Information</h3>
                      <div className="space-y-4">
                        <div className="flex items-start">
                          <Mail size={20} className="text-blue-400 mr-4 mt-1" />
                          <div>
                            <h4 className="font-medium text-gray-200">Email</h4>
                            <p className="text-blue-400">contact@muhammedfasil.com</p>
                          </div>
                        </div>
                        
                        <div className="flex items-start">
                          <Phone size={20} className="text-blue-400 mr-4 mt-1" />
                          <div>
                            <h4 className="font-medium text-gray-200">Phone</h4>
                            <p className="text-blue-400">+91 98765 43210</p>
                          </div>
                        </div>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="text-xl font-semibold mb-4 text-white">Office Location</h3>
                      <p className="text-gray-300">
                        Wincept Technologies Pvt Ltd<br />
                        Tech Park, Innovation Hub<br />
                        Bangalore, India
                      </p>
                    </div>
                    
                    <div className="bg-gray-900 p-6 rounded-xl border border-blue-500/20">
                      <h3 className="text-lg font-semibold mb-3 text-white">Let's Work Together</h3>
                      <p className="text-gray-300 mb-4">
                        Looking for AI consulting, speaking engagements, or collaboration opportunities?
                      </p>
                      <a 
                        href="mailto:contact@muhammedfasil.com" 
                        className="inline-block bg-transparent border border-blue-500 text-blue-400 hover:bg-blue-900/30 px-4 py-2 rounded-lg transition-all duration-300"
                      >
                        Schedule a Call
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-gray-900 border-t border-blue-900/30 py-12">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <div className="text-2xl font-bold bg-gradient-to-r from-blue-400 to-cyan-300 bg-clip-text text-transparent mb-2">
                Muhammed Fasil K
              </div>
              <p className="text-gray-400 text-sm">
                Innovating the Future with AI & Design
              </p>
            </div>
            
            <div className="flex space-x-6">
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Linkedin size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Twitter size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Github size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Youtube size={20} />
              </a>
              <a href="#" className="text-gray-400 hover:text-blue-400 transition-colors">
                <Mail size={20} />
              </a>
            </div>
          </div>
          
          <div className="border-t border-gray-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-500 text-sm mb-4 md:mb-0">
              &copy; {new Date().getFullYear()} Muhammed Fasil K. All rights reserved.
            </p>
            
            <div className="flex space-x-8">
              <a href="#" className="text-gray-500 hover:text-gray-300 text-sm transition-colors">Privacy Policy</a>
              <a href="#" className="text-gray-500 hover:text-gray-300 text-sm transition-colors">Terms of Service</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
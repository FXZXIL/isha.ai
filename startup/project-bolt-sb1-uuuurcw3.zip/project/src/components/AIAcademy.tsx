import React, { useEffect, useRef } from 'react';

const AIAcademy = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  const courses = [
    {
      title: "AI Fundamentals",
      description: "A comprehensive introduction to artificial intelligence concepts, algorithms, and applications.",
      duration: "8 weeks",
      level: "Beginner"
    },
    {
      title: "Machine Learning Mastery",
      description: "Deep dive into machine learning models, training techniques, and real-world implementation.",
      duration: "12 weeks",
      level: "Intermediate"
    },
    {
      title: "AI for Business Leaders",
      description: "Strategic framework for implementing AI solutions in business contexts and measuring ROI.",
      duration: "6 weeks",
      level: "Advanced"
    },
    {
      title: "Computer Vision Applications",
      description: "Hands-on course building practical computer vision applications for various industries.",
      duration: "10 weeks",
      level: "Intermediate"
    }
  ];

  return (
    <section id="ai-academy" className="py-20 bg-gray-900">
      <div ref={sectionRef} className="container mx-auto px-4 md:px-6 opacity-0 transition-opacity duration-1000">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">
              AI Academy
            </span>
          </h2>
          <p className="text-lg text-gray-300 text-center mb-12 max-w-3xl mx-auto">
            Empowering the next generation of AI innovators through accessible, practical education. My vision is to democratize AI knowledge and create a community of skilled practitioners.
          </p>

          <div className="bg-gradient-to-br from-gray-800 to-gray-900 p-8 rounded-2xl border border-gray-700 mb-12">
            <div className="grid md:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-bold mb-4 text-blue-400">Our Vision</h3>
                <p className="text-gray-300 mb-6">
                  To create an accessible pathway for anyone to master AI technologies and apply them to solve real-world problems. We believe that AI education should be practical, hands-on, and focused on implementation.
                </p>
                <p className="text-gray-300">
                  Through our academy, we're building a community of innovators who can harness the power of AI to create positive change in their industries and communities.
                </p>
              </div>
              <div className="rounded-xl overflow-hidden">
                <img 
                  src="https://images.unsplash.com/photo-1531482615713-2afd69097998?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80" 
                  alt="AI Academy" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>

          <h3 className="text-2xl font-bold mb-8 text-center text-gray-200">Featured Courses</h3>
          
          <div className="grid md:grid-cols-2 gap-6">
            {courses.map((course, index) => (
              <div 
                key={index}
                className="bg-gray-800/50 p-6 rounded-xl border border-gray-700 hover:border-blue-500 transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/10"
              >
                <h4 className="text-xl font-bold mb-2 text-white">{course.title}</h4>
                <p className="text-gray-300 mb-4">{course.description}</p>
                <div className="flex justify-between text-sm">
                  <span className="text-blue-400">{course.duration}</span>
                  <span className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full">
                    {course.level}
                  </span>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <button className="px-8 py-3 bg-gradient-to-r from-blue-600 to-purple-600 rounded-full text-white font-medium hover:shadow-lg hover:shadow-blue-500/20 transition-all duration-300">
              Join the Waitlist
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AIAcademy;
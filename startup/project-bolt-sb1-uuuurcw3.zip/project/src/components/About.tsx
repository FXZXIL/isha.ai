import React, { useEffect, useRef } from 'react';

const About = () => {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
    };
  }, []);

  return (
    <section id="about" className="py-20 bg-gray-900">
      <div ref={sectionRef} className="container mx-auto px-4 md:px-6 opacity-0 transition-opacity duration-1000">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-8 text-center">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">
              About Me
            </span>
          </h2>
          
          <div className="grid md:grid-cols-3 gap-8 items-center mb-12">
            <div className="md:col-span-1">
              <div className="relative">
                <div className="aspect-square rounded-2xl overflow-hidden">
                  <img 
                    src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=774&q=80" 
                    alt="Muhammed Fasil K" 
                    className="w-full h-full object-cover"
                  />
                </div>
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-t from-blue-600/30 to-transparent"></div>
              </div>
            </div>
            
            <div className="md:col-span-2">
              <p className="text-lg text-gray-300 mb-6">
                As the Founder & CTO of Wincept Technologies, I lead a team of innovators dedicated to creating impactful digital solutions. With over a decade of experience in technology and design, I've developed a unique perspective on how AI can transform businesses and education.
              </p>
              <p className="text-lg text-gray-300 mb-6">
                My journey began with a passion for solving complex problems through technology. Today, I combine my expertise in artificial intelligence, user experience design, and business strategy to build products that make a difference.
              </p>
              <p className="text-lg text-gray-300">
                I'm committed to sharing knowledge and empowering others through my AI Academy and YouTube channel, where I document my startup journey and provide insights into the world of technology entrepreneurship.
              </p>
            </div>
          </div>
          
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mt-12">
            <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700 hover:border-blue-500 transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/10">
              <h3 className="text-xl font-bold mb-2 text-blue-400">10+</h3>
              <p className="text-gray-400">Years Experience</p>
            </div>
            <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700 hover:border-blue-500 transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/10">
              <h3 className="text-xl font-bold mb-2 text-blue-400">50+</h3>
              <p className="text-gray-400">Projects Completed</p>
            </div>
            <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700 hover:border-blue-500 transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/10">
              <h3 className="text-xl font-bold mb-2 text-blue-400">20+</h3>
              <p className="text-gray-400">AI Solutions</p>
            </div>
            <div className="bg-gray-800/50 p-6 rounded-xl border border-gray-700 hover:border-blue-500 transition-all duration-300 hover:shadow-lg hover:shadow-blue-500/10">
              <h3 className="text-xl font-bold mb-2 text-blue-400">1000+</h3>
              <p className="text-gray-400">Students Mentored</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
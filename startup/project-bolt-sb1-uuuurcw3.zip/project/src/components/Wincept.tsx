import React, { useEffect, useRef } from 'react';

const Wincept = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const projectRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    projectRefs.current.forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
      projectRefs.current.forEach((ref) => {
        if (ref) observer.unobserve(ref);
      });
    };
  }, []);

  const projects = [
    {
      title: "AI-Powered Customer Service",
      description: "An intelligent chatbot system that handles customer inquiries with 95% accuracy, reducing response time by 60%.",
      image: "https://images.unsplash.com/photo-1531746790731-6c087fecd65a?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
      tags: ["AI", "NLP", "Customer Service"]
    },
    {
      title: "Smart Retail Analytics",
      description: "Computer vision solution for retail stores that analyzes customer behavior and optimizes product placement.",
      image: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
      tags: ["Computer Vision", "Analytics", "Retail"]
    },
    {
      title: "EdTech Platform",
      description: "Personalized learning platform that adapts to individual student needs using machine learning algorithms.",
      image: "https://images.unsplash.com/photo-1501504905252-473c47e087f8?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
      tags: ["EdTech", "Machine Learning", "Personalization"]
    }
  ];

  return (
    <section id="wincept" className="py-20 bg-gray-800">
      <div ref={sectionRef} className="container mx-auto px-4 md:px-6 opacity-0 transition-opacity duration-1000">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">
              Wincept Technologies
            </span>
          </h2>
          <p className="text-lg text-gray-300 text-center mb-12 max-w-3xl mx-auto">
            Founded with a vision to create innovative digital solutions that transform businesses. At Wincept, we combine cutting-edge technology with human-centered design to build products that matter.
          </p>

          <div className="grid md:grid-cols-2 gap-8 mb-16">
            <div className="bg-gray-900/80 p-8 rounded-xl border border-gray-700 hover:border-blue-500 transition-all duration-300">
              <h3 className="text-xl font-bold mb-4 text-blue-400">Our Mission</h3>
              <p className="text-gray-300">
                To empower businesses and individuals through innovative technology solutions that solve real-world problems and create meaningful impact.
              </p>
            </div>
            <div className="bg-gray-900/80 p-8 rounded-xl border border-gray-700 hover:border-blue-500 transition-all duration-300">
              <h3 className="text-xl font-bold mb-4 text-blue-400">Our Approach</h3>
              <p className="text-gray-300">
                We believe in a human-centered approach to technology. Every solution we build starts with understanding the people who will use it and the problems they face.
              </p>
            </div>
          </div>

          <h3 className="text-2xl font-bold mb-8 text-center text-gray-200">Featured Projects</h3>
          
          <div className="space-y-12">
            {projects.map((project, index) => (
              <div 
                key={index}
                ref={el => projectRefs.current[index] = el}
                className="flex flex-col md:flex-row gap-8 opacity-0 transition-opacity duration-1000"
              >
                <div className="md:w-1/2">
                  <div className="rounded-xl overflow-hidden aspect-video">
                    <img 
                      src={project.image} 
                      alt={project.title} 
                      className="w-full h-full object-cover transition-transform duration-500 hover:scale-105"
                    />
                  </div>
                </div>
                <div className="md:w-1/2 flex flex-col justify-center">
                  <h4 className="text-xl font-bold mb-3 text-white">{project.title}</h4>
                  <p className="text-gray-300 mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {project.tags.map((tag, tagIndex) => (
                      <span 
                        key={tagIndex} 
                        className="px-3 py-1 bg-blue-500/20 text-blue-300 rounded-full text-sm"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default Wincept;
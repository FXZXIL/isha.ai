import React, { useEffect, useRef } from 'react';
import { Youtube } from 'lucide-react';

const Social = () => {
  const sectionRef = useRef<HTMLDivElement>(null);
  const videoRefs = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add('animate-fade-in');
          }
        });
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    videoRefs.current.forEach((ref) => {
      if (ref) observer.observe(ref);
    });

    return () => {
      if (sectionRef.current) {
        observer.unobserve(sectionRef.current);
      }
      videoRefs.current.forEach((ref) => {
        if (ref) observer.unobserve(ref);
      });
    };
  }, []);

  const videos = [
    {
      title: "How We Built Our First AI Product",
      views: "24K views",
      date: "2 months ago",
      thumbnail: "https://images.unsplash.com/photo-1535303311164-664fc9ec6532?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
    },
    {
      title: "The Future of AI in Education",
      views: "18K views",
      date: "3 months ago",
      thumbnail: "https://images.unsplash.com/photo-1488190211105-8b0e65b80b4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
    },
    {
      title: "Day in the Life of a Tech Founder",
      views: "32K views",
      date: "1 month ago",
      thumbnail: "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80"
    }
  ];

  return (
    <section id="social" className="py-20 bg-gray-800">
      <div ref={sectionRef} className="container mx-auto px-4 md:px-6 opacity-0 transition-opacity duration-1000">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold mb-4 text-center">
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">
              YouTube & Social Media
            </span>
          </h2>
          <p className="text-lg text-gray-300 text-center mb-12 max-w-3xl mx-auto">
            Follow my journey as a tech entrepreneur and gain insights into AI, design, and building successful digital products. I share my experiences, challenges, and lessons learned along the way.
          </p>

          <div className="flex items-center justify-center mb-12">
            <a 
              href="#" 
              className="flex items-center gap-2 px-6 py-3 bg-red-600 hover:bg-red-700 rounded-full text-white font-medium transition-colors duration-300"
            >
              <Youtube size={20} />
              Subscribe to My Channel
            </a>
          </div>

          <h3 className="text-2xl font-bold mb-8 text-center text-gray-200">Featured Videos</h3>
          
          <div className="grid md:grid-cols-3 gap-6">
            {videos.map((video, index) => (
              <div 
                key={index}
                ref={el => videoRefs.current[index] = el}
                className="group bg-gray-900 rounded-xl overflow-hidden border border-gray-700 hover:border-blue-500 transition-all duration-300 opacity-0"
              >
                <div className="relative aspect-video">
                  <img 
                    src={video.thumbnail} 
                    alt={video.title} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-gray-900 to-transparent opacity-60"></div>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center">
                      <div className="w-0 h-0 border-t-[8px] border-t-transparent border-l-[16px] border-l-white border-b-[8px] border-b-transparent ml-1"></div>
                    </div>
                  </div>
                </div>
                <div className="p-4">
                  <h4 className="text-lg font-bold mb-2 text-white">{video.title}</h4>
                  <div className="flex justify-between text-sm text-gray-400">
                    <span>{video.views}</span>
                    <span>{video.date}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>

          <div className="mt-12 flex flex-wrap justify-center gap-4">
            <a href="#" className="text-blue-400 hover:text-blue-300 transition-colors">
              Twitter
            </a>
            <a href="#" className="text-blue-400 hover:text-blue-300 transition-colors">
              LinkedIn
            </a>
            <a href="#" className="text-blue-400 hover:text-blue-300 transition-colors">
              Instagram
            </a>
            <a href="#" className="text-blue-400 hover:text-blue-300 transition-colors">
              Medium
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Social;
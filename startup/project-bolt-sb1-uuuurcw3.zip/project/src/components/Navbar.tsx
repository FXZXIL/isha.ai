import React, { useState, useEffect } from 'react';
import { Menu, X } from 'lucide-react';

const Navbar = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 50) {
        setScrolled(true);
      } else {
        setScrolled(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const toggleMenu = () => {
    setIsOpen(!isOpen);
  };

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsOpen(false);
    }
  };

  return (
    <nav className={`fixed w-full z-50 transition-all duration-300 ${scrolled ? 'bg-gray-900/90 backdrop-blur-md py-2 shadow-lg' : 'bg-transparent py-4'}`}>
      <div className="container mx-auto px-4 md:px-6">
        <div className="flex justify-between items-center">
          <div className="flex items-center">
            <span className="text-xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">MFK</span>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex space-x-8">
            <button onClick={() => scrollToSection('about')} className="text-gray-300 hover:text-blue-400 transition-colors">About</button>
            <button onClick={() => scrollToSection('wincept')} className="text-gray-300 hover:text-blue-400 transition-colors">Wincept</button>
            <button onClick={() => scrollToSection('ai-academy')} className="text-gray-300 hover:text-blue-400 transition-colors">AI Academy</button>
            <button onClick={() => scrollToSection('social')} className="text-gray-300 hover:text-blue-400 transition-colors">YouTube</button>
            <button onClick={() => scrollToSection('contact')} className="text-gray-300 hover:text-blue-400 transition-colors">Contact</button>
          </div>

          {/* Mobile Menu Button */}
          <div className="md:hidden">
            <button onClick={toggleMenu} className="text-gray-300 hover:text-white">
              {isOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      <div className={`md:hidden transition-all duration-300 ease-in-out ${isOpen ? 'max-h-screen opacity-100' : 'max-h-0 opacity-0 invisible'}`}>
        <div className="bg-gray-800 px-4 py-5 space-y-4">
          <button onClick={() => scrollToSection('about')} className="block w-full text-left text-gray-300 hover:text-blue-400 transition-colors">About</button>
          <button onClick={() => scrollToSection('wincept')} className="block w-full text-left text-gray-300 hover:text-blue-400 transition-colors">Wincept</button>
          <button onClick={() => scrollToSection('ai-academy')} className="block w-full text-left text-gray-300 hover:text-blue-400 transition-colors">AI Academy</button>
          <button onClick={() => scrollToSection('social')} className="block w-full text-left text-gray-300 hover:text-blue-400 transition-colors">YouTube</button>
          <button onClick={() => scrollToSection('contact')} className="block w-full text-left text-gray-300 hover:text-blue-400 transition-colors">Contact</button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
import React, { useState, useEffect } from 'react';
import { Menu, X, Github, Linkedin, Youtube, Mail, Phone, ArrowRight, ChevronDown } from 'lucide-react';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Wincept from './components/Wincept';
import AIAcademy from './components/AIAcademy';
import Social from './components/Social';
import Contact from './components/Contact';
import Footer from './components/Footer';

function App() {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Simulate loading time
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 1500);

    return () => clearTimeout(timer);
  }, []);

  if (isLoading) {
    return (
      <div className="fixed inset-0 bg-black flex items-center justify-center">
        <div className="text-4xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 to-purple-600">
          <div className="flex items-center">
            <span className="animate-pulse">Muhammed Fasil K</span>
            <div className="ml-2 h-6 w-6 border-t-2 border-r-2 border-blue-500 animate-spin rounded-full"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-900 text-white">
      <Navbar />
      <main>
        <Hero />
        <About />
        <Wincept />
        <AIAcademy />
        <Social />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;